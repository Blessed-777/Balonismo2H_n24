public class Piloto extends Pessoa{
    public int num_reg_anac;

    // Get e Set
	public int getNum_reg_anac() {
		return num_reg_anac;
	}

	public void setNum_reg_anac(int num_reg_anac) {
		this.num_reg_anac = num_reg_anac;
	}
    
}
