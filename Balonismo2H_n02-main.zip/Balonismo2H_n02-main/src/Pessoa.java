public class Pessoa{
    // Atributos da Classe
    public String nome;
    public String CPF;
    public String RG;
    public String telefone;
    public String telefoneFamiliar;
    public Byte assinaturaTermo;
    public String endereço;
    // Métodos da Classe
    // Sobrescrito do Método
}
