public class Combustivel {
    // Atributos
    String tipo;
    String nome;
    boolean inspecaoRealizada;
    double preco;
    double Quantidade;
    String marca;
    double volume;

    // Métodos
    public String voar(Combustivel gasPropano){
        return "voando com " + gasPropano;
    }
}
