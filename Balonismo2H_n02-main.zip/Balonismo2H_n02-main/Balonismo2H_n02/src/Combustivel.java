public class Combustivel {
    // Atributos
    String tipoComb;
    String marcaComb;
    double precoComb;
    double quantidadeComb;

    // M�todos
    
    // Get e Set

	public String getTipoComb() {
		return tipoComb;
	}

	public void setTipoComb(String tipoComb) {
		this.tipoComb = tipoComb;
	}

	public double getPrecoComb() {
		return precoComb;
	}

	public void setPreco(double precoComb) {
		this.precoComb = precoComb;
	}

	public double getQuantidadeComb() {
		return quantidadeComb;
	}

	public void setQuantidadeComb(double quantidadeComb) {
		this.quantidadeComb = quantidadeComb;
	}

	public String getMarcaComb() {
		return marcaComb;
	}

	public void setMarca(String marcaComb) {
		this.marcaComb = marcaComb;
	}
    
}
