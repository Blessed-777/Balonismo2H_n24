public class Balao {
    public int capacidade;
    public int ID;
    public int reg_regularidade;
    // Métodos
    public String voar(Combustivel gasPropano){
        return "voando com" + gasPropano;
    }
}
