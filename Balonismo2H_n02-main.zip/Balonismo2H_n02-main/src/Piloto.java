public class Piloto extends Pessoa{
    public int num_reg_anac;
}
